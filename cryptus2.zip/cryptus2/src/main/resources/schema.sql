<<<<<<< HEAD
/*
CREATE SCHEMA  `cryptus`;
=======
CREATE SCHEMA `cryptus`;
>>>>>>> 066e68f5543f2d60036e4e19eeec637bb9ce5da9
USE `cryptus`;

CREATE TABLE IF NOT EXISTS `cryptus`.`bankinstelling`
(
    `Key`   VARCHAR(45) NOT NULL,
    `Value` VARCHAR(45) NOT NULL,

    PRIMARY KEY (`Key`)
);

CREATE TABLE if not exists `user`
(
    `userId`         INT          NOT NULL AUTO_INCREMENT,
    `voornaam`       VARCHAR(45)  NOT NULL,
    `tussenvoegsel`  VARCHAR(10)  NULL,
    `achternaam`     VARCHAR(45)  NOT NULL,
    `gebruikersnaam` VARCHAR(45)  NOT NULL,
    `wachtwoord`     VARCHAR(100) NOT NULL,

    PRIMARY KEY (`userId`)
    );
CREATE TABLE if not exists `klant`
(
    `userId`        INT         NOT NULL,
    `geboortedatum` DATE        NOT NULL,
    `straat`        VARCHAR(45) NOT NULL,
    `huisnummer`    INT         NOT NULL,
    `postcode`      VARCHAR(10) NOT NULL,
    `woonplaats`    VARCHAR(45) NOT NULL,
    `bsn`           VARCHAR(45) NOT NULL,
    `emailadres`    VARCHAR(45) NOT NULL,
    `telefoon`      VARCHAR(10) NOT NULL,
    PRIMARY KEY (`userId`),
    CONSTRAINT `verzinzelf`
    FOREIGN KEY (`userId`)
    REFERENCES `user` (`userId`)
    ON DELETE restrict
    ON UPDATE cascade
    );

CREATE TABLE if not exists `beheerder`
(
    `userId`           INT NOT NULL,
    `personeelsnummer` INT NOT NULL,
    PRIMARY KEY (`userId`),
    CONSTRAINT `verzinzelf1`
    FOREIGN KEY (`userId`)
    REFERENCES `user` (`userId`)
    ON DELETE restrict
    ON UPDATE cascade
    );
CREATE TABLE if not exists `bankrekening`
(
    `iban`   VARCHAR(45)    NOT NULL,
    `saldo`  DECIMAL(16, 2) NOT NULL,
    `userId` INT            NOT NULL,
    PRIMARY KEY (`iban`),
    CONSTRAINT `verzinzelf2`
    FOREIGN KEY (`userId`)
    REFERENCES `user` (`userId`)
    ON DELETE cascade
    ON UPDATE cascade
    );

CREATE TABLE if not exists `asset`
(
    `assetId`   INT         NOT NULL AUTO_INCREMENT,
    `naam`      VARCHAR(45) NOT NULL,
    `afkorting` VARCHAR(45) NOT NULL,
    PRIMARY KEY (`assetId`)
    );

CREATE TABLE if not exists `portefeuille`
(
    `portefeuilleID` INT NOT NULL AUTO_INCREMENT,
    `userId`         INT NOT NULL,
    PRIMARY KEY (`portefeuilleID`),
    CONSTRAINT `user_portefeuille`
    FOREIGN KEY (`userId`)
    REFERENCES `user` (`userId`)
    ON DELETE CASCADE
    ON UPDATE cascade
    );

CREATE TABLE if not exists `portefeuille_regel`
(
    `portefeuilleID` INT            NOT NULL,
    `assetId`        INT            NOT NULL,
    `saldo`          DECIMAL(16, 6) NOT NULL,
    PRIMARY KEY (`portefeuilleID`, `assetId`),
    CONSTRAINT `verzinzelf4`
    FOREIGN KEY (`portefeuilleID`)
    REFERENCES `portefeuille` (`portefeuilleID`)
    ON DELETE cascade
    ON UPDATE cascade,
    CONSTRAINT `verzinzelf5`
    FOREIGN KEY (`assetId`)
    REFERENCES `Asset` (`assetId`)
    ON DELETE no action
    ON UPDATE cascade
    );

CREATE TABLE IF NOT EXISTS `cryptus`.`transactie` (
    `transactieId` INT NOT NULL AUTO_INCREMENT,
    `datumtijd` TIMESTAMP(2) NOT NULL,
    `kosten` DECIMAL(2) NOT NULL,
    `creditiban` VARCHAR(45) NOT NULL,
    `debitiban` VARCHAR(45) NOT NULL,
    `euroammount` DECIMAL(6,2) NOT NULL,
    `debitportefeuilleID` INT NOT NULL,
    `debitassetId` INT NOT NULL,
    `assetammount` DECIMAL(6,2) NOT NULL,
    `creditportefeuilleID` INT NOT NULL,
    `creditassetId` INT NOT NULL,
    PRIMARY KEY (`transactieId`),
    CONSTRAINT `verzinzelf3`
    FOREIGN KEY (`debitportefeuilleID` , `debitassetId`)
    REFERENCES `cryptus`.`portefeuille_regel` (`portefeuilleID` , `assetId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
    CONSTRAINT `verzinzelf9`
    FOREIGN KEY (`creditiban`)
    REFERENCES `cryptus`.`bankrekening` (`iban`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
    CONSTRAINT `verzinzelf10`
    FOREIGN KEY (`debitiban`)
    REFERENCES `cryptus`.`bankrekening` (`iban`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
    CONSTRAINT `verzinzelf7`
    FOREIGN KEY (`creditportefeuilleID` , `creditassetId`)
    REFERENCES `cryptus`.`portefeuille_regel` (`portefeuilleID` , `assetId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

CREATE TABLE if not exists `koers`
(
    `asseta`      INT            NOT NULL,
    `assetb`      INT            NOT NULL,
    `wisselkoers` DECIMAL(16, 6) NOT NULL,
    `timestamp`   TIMESTAMP(2)   NOT NULL,
    PRIMARY KEY (`asseta`, `assetb`, `timestamp`),
    CONSTRAINT `verzinzelf6`
    FOREIGN KEY (`asseta`)
    REFERENCES `Asset` (`assetId`)
    ON DELETE NO ACTION
    ON UPDATE cascade,
    CONSTRAINT `verzinzelf8`
    FOREIGN KEY (`assetb`)
    REFERENCES `Asset` (`assetId`)
    ON DELETE cascade
    ON UPDATE cascade
    );

<<<<<<< HEAD


*/
=======
-- CREATE USER 'userCryptus'@'localhost' IDENTIFIED BY '12345';
-- GRANT ALL PRIVILEGES ON cryptus.* TO 'userCryptus'@'localhost';
>>>>>>> 066e68f5543f2d60036e4e19eeec637bb9ce5da9
