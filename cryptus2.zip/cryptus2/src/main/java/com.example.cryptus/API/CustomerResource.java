package com.example.cryptus.API;

public class CustomerResource {
//    private final
}
