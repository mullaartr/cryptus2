package com.example.cryptus.service;

public class AssetService {

}
