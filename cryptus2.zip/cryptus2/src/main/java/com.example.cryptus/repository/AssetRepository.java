package com.example.cryptus.repository;

public class AssetRepository {
}
