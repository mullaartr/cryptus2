package com.example.cryptus.controller;

import com.example.cryptus.dao.CustomerDaoJdbc;
import com.example.cryptus.model.Customer;
import com.example.cryptus.repository.CustomerRepository;
import com.example.cryptus.service.KlantenMakerService;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Date;
import java.util.Random;

public class KlantenMakerController {

    KlantenMakerService klantenMakerService = new KlantenMakerService();




}
