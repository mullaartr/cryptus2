package com.example.cryptus.dao;

public class AccountDaoJdbc implements AccountDao{

    @Override
    public void storeGebruikersNaam() {
    }

    @Override
    public void findGebruikersnaam() {

    }

    @Override
    public void updateGebruikersnaam() {

    }

    @Override
    public void storeWachtwoord() {

    }

    @Override
    public void updateWachtwoord() {

    }
}
