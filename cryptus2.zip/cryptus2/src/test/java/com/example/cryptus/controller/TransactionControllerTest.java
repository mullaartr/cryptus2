package com.example.cryptus.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TransactionControllerTest {

    @Test
    void getTransactionsFromUser() {
    }

    @Test
    void setCommisionPercentage() {
    }
}