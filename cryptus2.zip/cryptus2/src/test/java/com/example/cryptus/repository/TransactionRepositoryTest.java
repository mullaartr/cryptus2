package com.example.cryptus.repository;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TransactionRepositoryTest {

    @Test
    void findTransactionsByUser() {
    }

    @Test
    void testFindTransactionsByUser() {
    }
}